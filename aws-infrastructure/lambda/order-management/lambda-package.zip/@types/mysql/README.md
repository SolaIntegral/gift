# Installation
> `npm install --save @types/mysql`

# Summary
This package contains type definitions for mysql (https://github.com/mysqljs/mysql).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/mysql.

### Additional Details
 * Last updated: Wed, 26 Mar 2025 09:02:17 GMT
 * Dependencies: [@types/node](https://npmjs.com/package/@types/node)

# Credits
These definitions were written by [ William Johnston](https://github.com/wjohnsto), [Krittanan Pingclasai](https://github.com/kpping), [James Munro](https://github.com/jdmunro), and [Sanders DeNardi](https://github.com/sedenardi).
