# Installation
> `npm install --save @types/uuid`

# Summary
This package contains type definitions for uuid (https://github.com/uuidjs/uuid).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/uuid.

### Additional Details
 * Last updated: Thu, 25 Jan 2024 23:07:19 GMT
 * Dependencies: none

# Credits
These definitions were written by [Oliver Hoffmann](https://github.com/iamolivinius), [Felipe Ochoa](https://github.com/felipeochoa), [Chris Barth](https://github.com/cjbarth), [Linus Unnebäck](https://github.com/LinusU), and [Christoph Tavan](https://github.com/ctavan).
