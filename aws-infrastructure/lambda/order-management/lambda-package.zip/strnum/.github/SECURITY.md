If you believe you have found a security vulnerability in this repository which can be potentially harful for the users in anyway, please do not report security vulnerabilities through public GitHub issues. Instead, please report it to us as described below.

## Security contact information

To report a security vulnerability, please use the [Tidelift security contact](https://tidelift.com/security). Tidelift will coordinate the fix and disclosure.
