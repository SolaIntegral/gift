import { LoadedConfigSelectors } from "@smithy/node-config-provider";
export declare const NODE_AUTH_SCHEME_PREFERENCE_OPTIONS: LoadedConfigSelectors<
  string[]
>;
