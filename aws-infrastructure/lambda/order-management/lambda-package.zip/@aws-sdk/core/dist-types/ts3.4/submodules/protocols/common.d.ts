import { SerdeFunctions } from "@smithy/types";
export declare const collectBodyString: (
  streamBody: any,
  context: SerdeFunctions
) => Promise<string>;
