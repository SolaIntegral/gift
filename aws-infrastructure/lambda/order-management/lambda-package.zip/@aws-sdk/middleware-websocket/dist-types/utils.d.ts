import { HttpRequest } from "@smithy/types";
export declare const isWebSocketRequest: (request: HttpRequest) => boolean;
