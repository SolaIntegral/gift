import { EventStreamPayloadHandlerProvider } from "@smithy/types";
/** NodeJS event stream utils provider */
export declare const eventStreamPayloadHandlerProvider: EventStreamPayloadHandlerProvider;
