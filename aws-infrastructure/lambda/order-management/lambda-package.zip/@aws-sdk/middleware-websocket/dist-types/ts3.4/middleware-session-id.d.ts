import { InitializeHandlerOptions, InitializeMiddleware } from "@smithy/types";
export declare const injectSessionIdMiddleware: () => InitializeMiddleware<
  any,
  any
>;
export declare const injectSessionIdMiddlewareOptions: InitializeHandlerOptions;
