import { EventStreamPayloadHandlerProvider } from "@smithy/types";
export declare const eventStreamPayloadHandlerProvider: EventStreamPayloadHandlerProvider;
