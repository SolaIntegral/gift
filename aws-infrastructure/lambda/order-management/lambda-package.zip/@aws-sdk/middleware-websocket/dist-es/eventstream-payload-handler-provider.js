import { EventStreamPayloadHandler } from "./EventStreamPayloadHandler";
export const eventStreamPayloadHandlerProvider = (options) => new EventStreamPayloadHandler(options);
