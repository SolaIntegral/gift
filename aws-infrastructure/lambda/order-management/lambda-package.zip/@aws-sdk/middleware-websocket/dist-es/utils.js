export const isWebSocketRequest = (request) => request.protocol === "ws:" || request.protocol === "wss:";
