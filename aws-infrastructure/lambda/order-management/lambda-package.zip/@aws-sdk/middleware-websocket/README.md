# @aws-sdk/middleware-websocket

[![NPM version](https://img.shields.io/npm/v/@aws-sdk/middleware-websocket/latest.svg)](https://www.npmjs.com/package/@aws-sdk/middleware-websocket)
[![NPM downloads](https://img.shields.io/npm/dm/@aws-sdk/middleware-websocket.svg)](https://www.npmjs.com/package/@aws-sdk/middleware-websocket)

> An internal package

This package contains necessary dependency to support WebSocket connections for AWS services. These behaviors are subject to change.

## Usage

You probably shouldn't, at least directly.
