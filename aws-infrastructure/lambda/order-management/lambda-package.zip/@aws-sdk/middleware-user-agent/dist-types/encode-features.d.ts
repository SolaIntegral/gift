import type { AwsSdkFeatures } from "@aws-sdk/types";
/**
 * @internal
 */
export declare function encodeFeatures(features: AwsSdkFeatures): string;
