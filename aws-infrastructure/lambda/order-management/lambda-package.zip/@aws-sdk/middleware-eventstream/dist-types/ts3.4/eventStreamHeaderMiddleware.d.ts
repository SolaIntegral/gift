import { BuildHandlerOptions, BuildMiddleware } from "@smithy/types";
export declare const eventStreamHeaderMiddleware: BuildMiddleware<any, any>;
export declare const eventStreamHeaderMiddlewareOptions: BuildHandlerOptions;
