export declare const validateTokenKey: (
  key: string,
  value: unknown,
  forRefresh?: boolean
) => void;
