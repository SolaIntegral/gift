export declare const EXPIRE_WINDOW_MS: number;
export declare const REFRESH_MESSAGE =
  "To refresh this SSO session run 'aws sso login' with the corresponding profile.";
