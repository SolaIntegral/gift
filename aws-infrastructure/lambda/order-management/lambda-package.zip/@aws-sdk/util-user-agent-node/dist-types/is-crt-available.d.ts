import { UserAgentPair } from "@smithy/types";
/**
 * @internal
 */
export declare const isCrtAvailable: () => UserAgentPair | null;
