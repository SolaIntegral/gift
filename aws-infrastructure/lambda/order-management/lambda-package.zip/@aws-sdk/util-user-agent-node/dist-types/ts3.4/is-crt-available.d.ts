import { UserAgentPair } from "@smithy/types";
export declare const isCrtAvailable: () => UserAgentPair | null;
