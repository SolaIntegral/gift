export { URI } from "@smithy/types";
