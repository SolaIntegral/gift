export { MetadataBearer, ResponseMetadata } from "@smithy/types";
/**
 * @internal
 */
export interface Response {
    body: any;
}
