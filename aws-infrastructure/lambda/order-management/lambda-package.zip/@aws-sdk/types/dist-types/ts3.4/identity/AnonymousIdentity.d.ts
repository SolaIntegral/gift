import { Identity } from "./Identity";
export interface AnonymousIdentity extends Identity {}
