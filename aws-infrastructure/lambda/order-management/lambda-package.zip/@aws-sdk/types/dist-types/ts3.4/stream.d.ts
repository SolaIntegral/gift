export {
  GetAwsChunkedEncodingStream,
  GetAwsChunkedEncodingStreamOptions,
} from "@smithy/types";
