export { RequestHandlerProtocol, } from "@smithy/types";
