"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_bedrock_runtime_1 = require("@aws-sdk/client-bedrock-runtime");
const promise_1 = __importDefault(require("mysql2/promise"));
const bedrock = new client_bedrock_runtime_1.BedrockRuntimeClient({ region: 'us-west-2' });
// MySQL接続設定
const dbConfig = {
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    port: parseInt(process.env.DB_PORT || '3306'),
    ssl: process.env.DB_SSL === 'true' ? { rejectUnauthorized: false } : undefined
};
// AI推薦生成（Amazon Bedrock使用）
async function generateAIRecommendations(answers) {
    const prompt = `
    以下のユーザープロフィールに基づいて、最適な健康ギフトを3つ推薦してください：
    
    年齢: ${answers.age}
    性別: ${answers.gender}
    健康関心事: ${answers.healthConcerns.join(', ')}
    予算: ${answers.budget}
    関係性: ${answers.relationship || '未指定'}
    贈る機会: ${answers.occasion || '未指定'}
    
    各ギフトについて以下の形式で回答してください：
    1. ギフト名
    2. 推薦理由（健康面での効果を含む）
    3. 期待される効果
    4. 注意事項
    
    回答は日本語で、親しみやすく分かりやすい表現でお願いします。
  `;
    try {
        const command = new client_bedrock_runtime_1.InvokeModelCommand({
            modelId: process.env.BEDROCK_MODEL_ID || 'anthropic.claude-3-sonnet-20240229-v1:0',
            contentType: 'application/json',
            body: JSON.stringify({
                prompt: prompt,
                max_tokens: 1500,
                temperature: 0.7,
                top_p: 0.9,
            }),
        });
        const response = await bedrock.send(command);
        const result = JSON.parse(new TextDecoder().decode(response.body));
        return result.completion || 'AIからの推薦メッセージを生成できませんでした。';
    }
    catch (error) {
        console.error('Bedrock API error:', error);
        return 'AI推薦システムが一時的に利用できません。専門スタッフが手動でギフトを選択いたします。';
    }
}
// RDSからギフト取得
async function getGiftsFromDatabase(answers) {
    let connection = null;
    try {
        connection = await promise_1.default.createConnection(dbConfig);
        // 予算に基づく価格範囲を設定
        const budgetRanges = {
            '5000-10000': { min: 5000, max: 10000 },
            '10000-20000': { min: 10000, max: 20000 },
            '20000-30000': { min: 20000, max: 30000 },
            '30000-50000': { min: 30000, max: 50000 },
            '50000+': { min: 50000, max: 999999 },
        };
        const range = budgetRanges[answers.budget] || { min: 0, max: 999999 };
        const [rows] = await connection.execute(`SELECT id, name, description, price, category, partner_id, status, image_url, created_at 
       FROM gifts 
       WHERE status = 'active' 
       AND price >= ? AND price <= ? 
       ORDER BY price ASC 
       LIMIT 10`, [range.min, range.max]);
        return rows.map(row => ({
            id: row.id,
            name: row.name,
            description: row.description,
            price: row.price,
            category: row.category,
            partnerId: row.partner_id,
            status: row.status,
            imageUrl: row.image_url,
            createdAt: row.created_at,
        }));
    }
    catch (error) {
        console.error('Database error:', error);
        return [];
    }
    finally {
        if (connection) {
            await connection.end();
        }
    }
}
// 相談履歴保存
async function saveConsultation(userId, answers, recommendations) {
    let connection = null;
    try {
        connection = await promise_1.default.createConnection(dbConfig);
        // undefined値をnullに変換
        const safeUserId = userId || null;
        const safeAnswers = answers || null;
        const safeRecommendations = recommendations || null;
        const [result] = await connection.execute(`INSERT INTO consultations (id, user_id, answers, recommendations, created_at) 
       VALUES (UUID(), ?, ?, ?, NOW())`, [safeUserId, JSON.stringify(safeAnswers), JSON.stringify(safeRecommendations)]);
        return result.insertId;
    }
    catch (error) {
        console.error('Save consultation error:', error);
        throw error;
    }
    finally {
        if (connection) {
            await connection.end();
        }
    }
}
const handler = async (event) => {
    try {
        console.log('Event:', JSON.stringify(event, null, 2));
        const body = JSON.parse(event.body);
        const { answers, userId } = body;
        if (!answers) {
            return {
                statusCode: 400,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type',
                    'Access-Control-Allow-Methods': 'POST, OPTIONS'
                },
                body: JSON.stringify({
                    success: false,
                    error: '相談内容が提供されていません',
                    timestamp: new Date().toISOString(),
                })
            };
        }
        // データベースからギフト取得
        const gifts = await getGiftsFromDatabase(answers);
        if (gifts.length === 0) {
            return {
                statusCode: 404,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type',
                    'Access-Control-Allow-Methods': 'POST, OPTIONS'
                },
                body: JSON.stringify({
                    success: false,
                    error: '条件に合うギフトが見つかりませんでした',
                    timestamp: new Date().toISOString(),
                })
            };
        }
        // AI推薦生成
        const aiExplanation = await generateAIRecommendations(answers);
        // 上位3つのギフトを選択
        const recommendations = gifts.slice(0, 3);
        // 相談履歴保存（userIdが存在しない場合はデフォルト値を設定）
        const defaultUserId = userId || 'anonymous';
        const consultationId = await saveConsultation(defaultUserId, answers, recommendations);
        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'POST, OPTIONS'
            },
            body: JSON.stringify({
                success: true,
                data: {
                    consultationId: consultationId.toString(),
                    recommendations,
                    aiExplanation,
                },
                timestamp: new Date().toISOString(),
            })
        };
    }
    catch (error) {
        console.error('Error:', error);
        return {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'POST, OPTIONS'
            },
            body: JSON.stringify({
                success: false,
                error: 'ギフト推薦の生成に失敗しました',
                timestamp: new Date().toISOString(),
            })
        };
    }
};
exports.handler = handler;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJpbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7QUFBQSw0RUFBMEY7QUFDMUYsNkRBQWtDO0FBRWxDLE1BQU0sT0FBTyxHQUFHLElBQUksNkNBQW9CLENBQUMsRUFBRSxNQUFNLEVBQUUsV0FBVyxFQUFFLENBQUMsQ0FBQTtBQUVqRSxZQUFZO0FBQ1osTUFBTSxRQUFRLEdBQUc7SUFDZixJQUFJLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxPQUFRO0lBQzFCLElBQUksRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLE9BQVE7SUFDMUIsUUFBUSxFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBWTtJQUNsQyxRQUFRLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxPQUFRO0lBQzlCLElBQUksRUFBRSxRQUFRLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxPQUFPLElBQUksTUFBTSxDQUFDO0lBQzdDLEdBQUcsRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLE1BQU0sS0FBSyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsa0JBQWtCLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDLFNBQVM7Q0FDL0UsQ0FBQTtBQThCRCwyQkFBMkI7QUFDM0IsS0FBSyxVQUFVLHlCQUF5QixDQUFDLE9BQTRCO0lBQ25FLE1BQU0sTUFBTSxHQUFHOzs7VUFHUCxPQUFPLENBQUMsR0FBRztVQUNYLE9BQU8sQ0FBQyxNQUFNO2FBQ1gsT0FBTyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO1VBQ3BDLE9BQU8sQ0FBQyxNQUFNO1dBQ2IsT0FBTyxDQUFDLFlBQVksSUFBSSxLQUFLO1lBQzVCLE9BQU8sQ0FBQyxRQUFRLElBQUksS0FBSzs7Ozs7Ozs7O0dBU2xDLENBQUE7SUFFRCxJQUFJO1FBQ0YsTUFBTSxPQUFPLEdBQUcsSUFBSSwyQ0FBa0IsQ0FBQztZQUNyQyxPQUFPLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsSUFBSSx5Q0FBeUM7WUFDbEYsV0FBVyxFQUFFLGtCQUFrQjtZQUMvQixJQUFJLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQztnQkFDbkIsTUFBTSxFQUFFLE1BQU07Z0JBQ2QsVUFBVSxFQUFFLElBQUk7Z0JBQ2hCLFdBQVcsRUFBRSxHQUFHO2dCQUNoQixLQUFLLEVBQUUsR0FBRzthQUNYLENBQUM7U0FDSCxDQUFDLENBQUE7UUFFRixNQUFNLFFBQVEsR0FBRyxNQUFNLE9BQU8sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUE7UUFDNUMsTUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLFdBQVcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQTtRQUVsRSxPQUFPLE1BQU0sQ0FBQyxVQUFVLElBQUksMEJBQTBCLENBQUE7S0FDdkQ7SUFBQyxPQUFPLEtBQUssRUFBRTtRQUNkLE9BQU8sQ0FBQyxLQUFLLENBQUMsb0JBQW9CLEVBQUUsS0FBSyxDQUFDLENBQUE7UUFDMUMsT0FBTyw2Q0FBNkMsQ0FBQTtLQUNyRDtBQUNILENBQUM7QUFFRCxhQUFhO0FBQ2IsS0FBSyxVQUFVLG9CQUFvQixDQUFDLE9BQTRCO0lBQzlELElBQUksVUFBVSxHQUE0QixJQUFJLENBQUE7SUFFOUMsSUFBSTtRQUNGLFVBQVUsR0FBRyxNQUFNLGlCQUFLLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxDQUFDLENBQUE7UUFFbkQsZ0JBQWdCO1FBQ2hCLE1BQU0sWUFBWSxHQUFpRDtZQUNqRSxZQUFZLEVBQUUsRUFBRSxHQUFHLEVBQUUsSUFBSSxFQUFFLEdBQUcsRUFBRSxLQUFLLEVBQUU7WUFDdkMsYUFBYSxFQUFFLEVBQUUsR0FBRyxFQUFFLEtBQUssRUFBRSxHQUFHLEVBQUUsS0FBSyxFQUFFO1lBQ3pDLGFBQWEsRUFBRSxFQUFFLEdBQUcsRUFBRSxLQUFLLEVBQUUsR0FBRyxFQUFFLEtBQUssRUFBRTtZQUN6QyxhQUFhLEVBQUUsRUFBRSxHQUFHLEVBQUUsS0FBSyxFQUFFLEdBQUcsRUFBRSxLQUFLLEVBQUU7WUFDekMsUUFBUSxFQUFFLEVBQUUsR0FBRyxFQUFFLEtBQUssRUFBRSxHQUFHLEVBQUUsTUFBTSxFQUFFO1NBQ3RDLENBQUE7UUFFRCxNQUFNLEtBQUssR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsR0FBRyxFQUFFLENBQUMsRUFBRSxHQUFHLEVBQUUsTUFBTSxFQUFFLENBQUE7UUFFckUsTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHLE1BQU0sVUFBVSxDQUFDLE9BQU8sQ0FDckM7Ozs7O2dCQUtVLEVBQ1YsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FDdkIsQ0FBQTtRQUVELE9BQVEsSUFBYyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUM7WUFDakMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxFQUFFO1lBQ1YsSUFBSSxFQUFFLEdBQUcsQ0FBQyxJQUFJO1lBQ2QsV0FBVyxFQUFFLEdBQUcsQ0FBQyxXQUFXO1lBQzVCLEtBQUssRUFBRSxHQUFHLENBQUMsS0FBSztZQUNoQixRQUFRLEVBQUUsR0FBRyxDQUFDLFFBQVE7WUFDdEIsU0FBUyxFQUFFLEdBQUcsQ0FBQyxVQUFVO1lBQ3pCLE1BQU0sRUFBRSxHQUFHLENBQUMsTUFBTTtZQUNsQixRQUFRLEVBQUUsR0FBRyxDQUFDLFNBQVM7WUFDdkIsU0FBUyxFQUFFLEdBQUcsQ0FBQyxVQUFVO1NBQzFCLENBQUMsQ0FBQyxDQUFBO0tBQ0o7SUFBQyxPQUFPLEtBQUssRUFBRTtRQUNkLE9BQU8sQ0FBQyxLQUFLLENBQUMsaUJBQWlCLEVBQUUsS0FBSyxDQUFDLENBQUE7UUFDdkMsT0FBTyxFQUFFLENBQUE7S0FDVjtZQUFTO1FBQ1IsSUFBSSxVQUFVLEVBQUU7WUFDZCxNQUFNLFVBQVUsQ0FBQyxHQUFHLEVBQUUsQ0FBQTtTQUN2QjtLQUNGO0FBQ0gsQ0FBQztBQUVELFNBQVM7QUFDVCxLQUFLLFVBQVUsZ0JBQWdCLENBQUMsTUFBYyxFQUFFLE9BQTRCLEVBQUUsZUFBdUI7SUFDbkcsSUFBSSxVQUFVLEdBQTRCLElBQUksQ0FBQTtJQUU5QyxJQUFJO1FBQ0YsVUFBVSxHQUFHLE1BQU0saUJBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLENBQUMsQ0FBQTtRQUVuRCxxQkFBcUI7UUFDckIsTUFBTSxVQUFVLEdBQUcsTUFBTSxJQUFJLElBQUksQ0FBQTtRQUNqQyxNQUFNLFdBQVcsR0FBRyxPQUFPLElBQUksSUFBSSxDQUFBO1FBQ25DLE1BQU0sbUJBQW1CLEdBQUcsZUFBZSxJQUFJLElBQUksQ0FBQTtRQUVuRCxNQUFNLENBQUMsTUFBTSxDQUFDLEdBQUcsTUFBTSxVQUFVLENBQUMsT0FBTyxDQUN2Qzt1Q0FDaUMsRUFDakMsQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FDL0UsQ0FBQTtRQUVELE9BQVEsTUFBYyxDQUFDLFFBQVEsQ0FBQTtLQUNoQztJQUFDLE9BQU8sS0FBSyxFQUFFO1FBQ2QsT0FBTyxDQUFDLEtBQUssQ0FBQywwQkFBMEIsRUFBRSxLQUFLLENBQUMsQ0FBQTtRQUNoRCxNQUFNLEtBQUssQ0FBQTtLQUNaO1lBQVM7UUFDUixJQUFJLFVBQVUsRUFBRTtZQUNkLE1BQU0sVUFBVSxDQUFDLEdBQUcsRUFBRSxDQUFBO1NBQ3ZCO0tBQ0Y7QUFDSCxDQUFDO0FBRU0sTUFBTSxPQUFPLEdBQUcsS0FBSyxFQUFFLEtBQVUsRUFBZ0IsRUFBRTtJQUN4RCxJQUFJO1FBQ0YsT0FBTyxDQUFDLEdBQUcsQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUE7UUFFckQsTUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUE7UUFDbkMsTUFBTSxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsR0FBRyxJQUFJLENBQUE7UUFFaEMsSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUNaLE9BQU87Z0JBQ0wsVUFBVSxFQUFFLEdBQUc7Z0JBQ2YsT0FBTyxFQUFFO29CQUNQLGNBQWMsRUFBRSxrQkFBa0I7b0JBQ2xDLDZCQUE2QixFQUFFLEdBQUc7b0JBQ2xDLDhCQUE4QixFQUFFLGNBQWM7b0JBQzlDLDhCQUE4QixFQUFFLGVBQWU7aUJBQ2hEO2dCQUNELElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDO29CQUNuQixPQUFPLEVBQUUsS0FBSztvQkFDZCxLQUFLLEVBQUUsZ0JBQWdCO29CQUN2QixTQUFTLEVBQUUsSUFBSSxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUU7aUJBQ3BDLENBQUM7YUFDSCxDQUFBO1NBQ0Y7UUFFRCxnQkFBZ0I7UUFDaEIsTUFBTSxLQUFLLEdBQUcsTUFBTSxvQkFBb0IsQ0FBQyxPQUFPLENBQUMsQ0FBQTtRQUVqRCxJQUFJLEtBQUssQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO1lBQ3RCLE9BQU87Z0JBQ0wsVUFBVSxFQUFFLEdBQUc7Z0JBQ2YsT0FBTyxFQUFFO29CQUNQLGNBQWMsRUFBRSxrQkFBa0I7b0JBQ2xDLDZCQUE2QixFQUFFLEdBQUc7b0JBQ2xDLDhCQUE4QixFQUFFLGNBQWM7b0JBQzlDLDhCQUE4QixFQUFFLGVBQWU7aUJBQ2hEO2dCQUNELElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDO29CQUNuQixPQUFPLEVBQUUsS0FBSztvQkFDZCxLQUFLLEVBQUUscUJBQXFCO29CQUM1QixTQUFTLEVBQUUsSUFBSSxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUU7aUJBQ3BDLENBQUM7YUFDSCxDQUFBO1NBQ0Y7UUFFRCxTQUFTO1FBQ1QsTUFBTSxhQUFhLEdBQUcsTUFBTSx5QkFBeUIsQ0FBQyxPQUFPLENBQUMsQ0FBQTtRQUU5RCxjQUFjO1FBQ2QsTUFBTSxlQUFlLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUE7UUFFekMsbUNBQW1DO1FBQ25DLE1BQU0sYUFBYSxHQUFHLE1BQU0sSUFBSSxXQUFXLENBQUE7UUFDM0MsTUFBTSxjQUFjLEdBQUcsTUFBTSxnQkFBZ0IsQ0FBQyxhQUFhLEVBQUUsT0FBTyxFQUFFLGVBQWUsQ0FBQyxDQUFBO1FBRXRGLE9BQU87WUFDTCxVQUFVLEVBQUUsR0FBRztZQUNmLE9BQU8sRUFBRTtnQkFDUCxjQUFjLEVBQUUsa0JBQWtCO2dCQUNsQyw2QkFBNkIsRUFBRSxHQUFHO2dCQUNsQyw4QkFBOEIsRUFBRSxjQUFjO2dCQUM5Qyw4QkFBOEIsRUFBRSxlQUFlO2FBQ2hEO1lBQ0QsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUM7Z0JBQ25CLE9BQU8sRUFBRSxJQUFJO2dCQUNiLElBQUksRUFBRTtvQkFDSixjQUFjLEVBQUUsY0FBYyxDQUFDLFFBQVEsRUFBRTtvQkFDekMsZUFBZTtvQkFDZixhQUFhO2lCQUNkO2dCQUNELFNBQVMsRUFBRSxJQUFJLElBQUksRUFBRSxDQUFDLFdBQVcsRUFBRTthQUNwQyxDQUFDO1NBQ0gsQ0FBQTtLQUVGO0lBQUMsT0FBTyxLQUFLLEVBQUU7UUFDZCxPQUFPLENBQUMsS0FBSyxDQUFDLFFBQVEsRUFBRSxLQUFLLENBQUMsQ0FBQTtRQUU5QixPQUFPO1lBQ0wsVUFBVSxFQUFFLEdBQUc7WUFDZixPQUFPLEVBQUU7Z0JBQ1AsY0FBYyxFQUFFLGtCQUFrQjtnQkFDbEMsNkJBQTZCLEVBQUUsR0FBRztnQkFDbEMsOEJBQThCLEVBQUUsY0FBYztnQkFDOUMsOEJBQThCLEVBQUUsZUFBZTthQUNoRDtZQUNELElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDO2dCQUNuQixPQUFPLEVBQUUsS0FBSztnQkFDZCxLQUFLLEVBQUUsaUJBQWlCO2dCQUN4QixTQUFTLEVBQUUsSUFBSSxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUU7YUFDcEMsQ0FBQztTQUNILENBQUE7S0FDRjtBQUNILENBQUMsQ0FBQTtBQTNGWSxRQUFBLE9BQU8sV0EyRm5CIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQmVkcm9ja1J1bnRpbWVDbGllbnQsIEludm9rZU1vZGVsQ29tbWFuZCB9IGZyb20gJ0Bhd3Mtc2RrL2NsaWVudC1iZWRyb2NrLXJ1bnRpbWUnXG5pbXBvcnQgbXlzcWwgZnJvbSAnbXlzcWwyL3Byb21pc2UnXG5cbmNvbnN0IGJlZHJvY2sgPSBuZXcgQmVkcm9ja1J1bnRpbWVDbGllbnQoeyByZWdpb246ICd1cy13ZXN0LTInIH0pXG5cbi8vIE15U1FM5o6l57aa6Kit5a6aXG5jb25zdCBkYkNvbmZpZyA9IHtcbiAgaG9zdDogcHJvY2Vzcy5lbnYuREJfSE9TVCEsXG4gIHVzZXI6IHByb2Nlc3MuZW52LkRCX1VTRVIhLFxuICBwYXNzd29yZDogcHJvY2Vzcy5lbnYuREJfUEFTU1dPUkQhLFxuICBkYXRhYmFzZTogcHJvY2Vzcy5lbnYuREJfTkFNRSEsXG4gIHBvcnQ6IHBhcnNlSW50KHByb2Nlc3MuZW52LkRCX1BPUlQgfHwgJzMzMDYnKSxcbiAgc3NsOiBwcm9jZXNzLmVudi5EQl9TU0wgPT09ICd0cnVlJyA/IHsgcmVqZWN0VW5hdXRob3JpemVkOiBmYWxzZSB9IDogdW5kZWZpbmVkXG59XG5cbmludGVyZmFjZSBDb25zdWx0YXRpb25BbnN3ZXJzIHtcbiAgYWdlOiBzdHJpbmdcbiAgZ2VuZGVyOiBzdHJpbmdcbiAgaGVhbHRoQ29uY2VybnM6IHN0cmluZ1tdXG4gIGJ1ZGdldDogc3RyaW5nXG4gIHJlbGF0aW9uc2hpcD86IHN0cmluZ1xuICBvY2Nhc2lvbj86IHN0cmluZ1xufVxuXG5pbnRlcmZhY2UgR2lmdCB7XG4gIGlkOiBzdHJpbmdcbiAgbmFtZTogc3RyaW5nXG4gIGRlc2NyaXB0aW9uOiBzdHJpbmdcbiAgcHJpY2U6IG51bWJlclxuICBjYXRlZ29yeTogc3RyaW5nXG4gIHBhcnRuZXJJZD86IHN0cmluZ1xuICBzdGF0dXM6IHN0cmluZ1xuICBpbWFnZVVybD86IHN0cmluZ1xuICBjcmVhdGVkQXQ6IHN0cmluZ1xufVxuXG5pbnRlcmZhY2UgQXBpUmVzcG9uc2U8VD4ge1xuICBzdWNjZXNzOiBib29sZWFuXG4gIGRhdGE/OiBUXG4gIGVycm9yPzogc3RyaW5nXG4gIHRpbWVzdGFtcDogc3RyaW5nXG59XG5cbi8vIEFJ5o6o6Jam55Sf5oiQ77yIQW1hem9uIEJlZHJvY2vkvb/nlKjvvIlcbmFzeW5jIGZ1bmN0aW9uIGdlbmVyYXRlQUlSZWNvbW1lbmRhdGlvbnMoYW5zd2VyczogQ29uc3VsdGF0aW9uQW5zd2Vycyk6IFByb21pc2U8c3RyaW5nPiB7XG4gIGNvbnN0IHByb21wdCA9IGBcbiAgICDku6XkuIvjga7jg6bjg7zjgrbjg7zjg5fjg63jg5XjgqPjg7zjg6vjgavln7rjgaXjgYTjgabjgIHmnIDpganjgarlgaXlurfjgq7jg5Xjg4jjgpIz44Gk5o6o6Jam44GX44Gm44GP44Gg44GV44GE77yaXG4gICAgXG4gICAg5bm06b2iOiAke2Fuc3dlcnMuYWdlfVxuICAgIOaAp+WIpTogJHthbnN3ZXJzLmdlbmRlcn1cbiAgICDlgaXlurfplqLlv4Pkuos6ICR7YW5zd2Vycy5oZWFsdGhDb25jZXJucy5qb2luKCcsICcpfVxuICAgIOS6iOeulzogJHthbnN3ZXJzLmJ1ZGdldH1cbiAgICDplqLkv4LmgKc6ICR7YW5zd2Vycy5yZWxhdGlvbnNoaXAgfHwgJ+acquaMh+Wumid9XG4gICAg6LSI44KL5qmf5LyaOiAke2Fuc3dlcnMub2NjYXNpb24gfHwgJ+acquaMh+Wumid9XG4gICAgXG4gICAg5ZCE44Ku44OV44OI44Gr44Gk44GE44Gm5Lul5LiL44Gu5b2i5byP44Gn5Zue562U44GX44Gm44GP44Gg44GV44GE77yaXG4gICAgMS4g44Ku44OV44OI5ZCNXG4gICAgMi4g5o6o6Jam55CG55Sx77yI5YGl5bq36Z2i44Gn44Gu5Yq55p6c44KS5ZCr44KA77yJXG4gICAgMy4g5pyf5b6F44GV44KM44KL5Yq55p6cXG4gICAgNC4g5rOo5oSP5LqL6aCFXG4gICAgXG4gICAg5Zue562U44Gv5pel5pys6Kqe44Gn44CB6Kaq44GX44G/44KE44GZ44GP5YiG44GL44KK44KE44GZ44GE6KGo54++44Gn44GK6aGY44GE44GX44G+44GZ44CCXG4gIGBcblxuICB0cnkge1xuICAgIGNvbnN0IGNvbW1hbmQgPSBuZXcgSW52b2tlTW9kZWxDb21tYW5kKHtcbiAgICAgIG1vZGVsSWQ6IHByb2Nlc3MuZW52LkJFRFJPQ0tfTU9ERUxfSUQgfHwgJ2FudGhyb3BpYy5jbGF1ZGUtMy1zb25uZXQtMjAyNDAyMjktdjE6MCcsXG4gICAgICBjb250ZW50VHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICBwcm9tcHQ6IHByb21wdCxcbiAgICAgICAgbWF4X3Rva2VuczogMTUwMCxcbiAgICAgICAgdGVtcGVyYXR1cmU6IDAuNyxcbiAgICAgICAgdG9wX3A6IDAuOSxcbiAgICAgIH0pLFxuICAgIH0pXG5cbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGJlZHJvY2suc2VuZChjb21tYW5kKVxuICAgIGNvbnN0IHJlc3VsdCA9IEpTT04ucGFyc2UobmV3IFRleHREZWNvZGVyKCkuZGVjb2RlKHJlc3BvbnNlLmJvZHkpKVxuICAgIFxuICAgIHJldHVybiByZXN1bHQuY29tcGxldGlvbiB8fCAnQUnjgYvjgonjga7mjqjolqbjg6Hjg4Pjgrvjg7zjgrjjgpLnlJ/miJDjgafjgY3jgb7jgZvjgpPjgafjgZfjgZ/jgIInXG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29uc29sZS5lcnJvcignQmVkcm9jayBBUEkgZXJyb3I6JywgZXJyb3IpXG4gICAgcmV0dXJuICdBSeaOqOiWpuOCt+OCueODhuODoOOBjOS4gOaZgueahOOBq+WIqeeUqOOBp+OBjeOBvuOBm+OCk+OAguWwgumWgOOCueOCv+ODg+ODleOBjOaJi+WLleOBp+OCruODleODiOOCkumBuOaKnuOBhOOBn+OBl+OBvuOBmeOAgidcbiAgfVxufVxuXG4vLyBSRFPjgYvjgonjgq7jg5Xjg4jlj5blvpdcbmFzeW5jIGZ1bmN0aW9uIGdldEdpZnRzRnJvbURhdGFiYXNlKGFuc3dlcnM6IENvbnN1bHRhdGlvbkFuc3dlcnMpOiBQcm9taXNlPEdpZnRbXT4ge1xuICBsZXQgY29ubmVjdGlvbjogbXlzcWwuQ29ubmVjdGlvbiB8IG51bGwgPSBudWxsXG4gIFxuICB0cnkge1xuICAgIGNvbm5lY3Rpb24gPSBhd2FpdCBteXNxbC5jcmVhdGVDb25uZWN0aW9uKGRiQ29uZmlnKVxuICAgIFxuICAgIC8vIOS6iOeul+OBq+WfuuOBpeOBj+S+oeagvOevhOWbsuOCkuioreWumlxuICAgIGNvbnN0IGJ1ZGdldFJhbmdlczogUmVjb3JkPHN0cmluZywgeyBtaW46IG51bWJlcjsgbWF4OiBudW1iZXIgfT4gPSB7XG4gICAgICAnNTAwMC0xMDAwMCc6IHsgbWluOiA1MDAwLCBtYXg6IDEwMDAwIH0sXG4gICAgICAnMTAwMDAtMjAwMDAnOiB7IG1pbjogMTAwMDAsIG1heDogMjAwMDAgfSxcbiAgICAgICcyMDAwMC0zMDAwMCc6IHsgbWluOiAyMDAwMCwgbWF4OiAzMDAwMCB9LFxuICAgICAgJzMwMDAwLTUwMDAwJzogeyBtaW46IDMwMDAwLCBtYXg6IDUwMDAwIH0sXG4gICAgICAnNTAwMDArJzogeyBtaW46IDUwMDAwLCBtYXg6IDk5OTk5OSB9LFxuICAgIH1cbiAgICBcbiAgICBjb25zdCByYW5nZSA9IGJ1ZGdldFJhbmdlc1thbnN3ZXJzLmJ1ZGdldF0gfHwgeyBtaW46IDAsIG1heDogOTk5OTk5IH1cbiAgICBcbiAgICBjb25zdCBbcm93c10gPSBhd2FpdCBjb25uZWN0aW9uLmV4ZWN1dGUoXG4gICAgICBgU0VMRUNUIGlkLCBuYW1lLCBkZXNjcmlwdGlvbiwgcHJpY2UsIGNhdGVnb3J5LCBwYXJ0bmVyX2lkLCBzdGF0dXMsIGltYWdlX3VybCwgY3JlYXRlZF9hdCBcbiAgICAgICBGUk9NIGdpZnRzIFxuICAgICAgIFdIRVJFIHN0YXR1cyA9ICdhY3RpdmUnIFxuICAgICAgIEFORCBwcmljZSA+PSA/IEFORCBwcmljZSA8PSA/IFxuICAgICAgIE9SREVSIEJZIHByaWNlIEFTQyBcbiAgICAgICBMSU1JVCAxMGAsXG4gICAgICBbcmFuZ2UubWluLCByYW5nZS5tYXhdXG4gICAgKVxuXG4gICAgcmV0dXJuIChyb3dzIGFzIGFueVtdKS5tYXAocm93ID0+ICh7XG4gICAgICBpZDogcm93LmlkLFxuICAgICAgbmFtZTogcm93Lm5hbWUsXG4gICAgICBkZXNjcmlwdGlvbjogcm93LmRlc2NyaXB0aW9uLFxuICAgICAgcHJpY2U6IHJvdy5wcmljZSxcbiAgICAgIGNhdGVnb3J5OiByb3cuY2F0ZWdvcnksXG4gICAgICBwYXJ0bmVySWQ6IHJvdy5wYXJ0bmVyX2lkLFxuICAgICAgc3RhdHVzOiByb3cuc3RhdHVzLFxuICAgICAgaW1hZ2VVcmw6IHJvdy5pbWFnZV91cmwsXG4gICAgICBjcmVhdGVkQXQ6IHJvdy5jcmVhdGVkX2F0LFxuICAgIH0pKVxuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGNvbnNvbGUuZXJyb3IoJ0RhdGFiYXNlIGVycm9yOicsIGVycm9yKVxuICAgIHJldHVybiBbXVxuICB9IGZpbmFsbHkge1xuICAgIGlmIChjb25uZWN0aW9uKSB7XG4gICAgICBhd2FpdCBjb25uZWN0aW9uLmVuZCgpXG4gICAgfVxuICB9XG59XG5cbi8vIOebuOirh+WxpeattOS/neWtmFxuYXN5bmMgZnVuY3Rpb24gc2F2ZUNvbnN1bHRhdGlvbih1c2VySWQ6IHN0cmluZywgYW5zd2VyczogQ29uc3VsdGF0aW9uQW5zd2VycywgcmVjb21tZW5kYXRpb25zOiBHaWZ0W10pIHtcbiAgbGV0IGNvbm5lY3Rpb246IG15c3FsLkNvbm5lY3Rpb24gfCBudWxsID0gbnVsbFxuICBcbiAgdHJ5IHtcbiAgICBjb25uZWN0aW9uID0gYXdhaXQgbXlzcWwuY3JlYXRlQ29ubmVjdGlvbihkYkNvbmZpZylcbiAgICBcbiAgICAvLyB1bmRlZmluZWTlgKTjgpJudWxs44Gr5aSJ5o+bXG4gICAgY29uc3Qgc2FmZVVzZXJJZCA9IHVzZXJJZCB8fCBudWxsXG4gICAgY29uc3Qgc2FmZUFuc3dlcnMgPSBhbnN3ZXJzIHx8IG51bGxcbiAgICBjb25zdCBzYWZlUmVjb21tZW5kYXRpb25zID0gcmVjb21tZW5kYXRpb25zIHx8IG51bGxcbiAgICBcbiAgICBjb25zdCBbcmVzdWx0XSA9IGF3YWl0IGNvbm5lY3Rpb24uZXhlY3V0ZShcbiAgICAgIGBJTlNFUlQgSU5UTyBjb25zdWx0YXRpb25zIChpZCwgdXNlcl9pZCwgYW5zd2VycywgcmVjb21tZW5kYXRpb25zLCBjcmVhdGVkX2F0KSBcbiAgICAgICBWQUxVRVMgKFVVSUQoKSwgPywgPywgPywgTk9XKCkpYCxcbiAgICAgIFtzYWZlVXNlcklkLCBKU09OLnN0cmluZ2lmeShzYWZlQW5zd2VycyksIEpTT04uc3RyaW5naWZ5KHNhZmVSZWNvbW1lbmRhdGlvbnMpXVxuICAgIClcblxuICAgIHJldHVybiAocmVzdWx0IGFzIGFueSkuaW5zZXJ0SWRcbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBjb25zb2xlLmVycm9yKCdTYXZlIGNvbnN1bHRhdGlvbiBlcnJvcjonLCBlcnJvcilcbiAgICB0aHJvdyBlcnJvclxuICB9IGZpbmFsbHkge1xuICAgIGlmIChjb25uZWN0aW9uKSB7XG4gICAgICBhd2FpdCBjb25uZWN0aW9uLmVuZCgpXG4gICAgfVxuICB9XG59XG5cbmV4cG9ydCBjb25zdCBoYW5kbGVyID0gYXN5bmMgKGV2ZW50OiBhbnkpOiBQcm9taXNlPGFueT4gPT4ge1xuICB0cnkge1xuICAgIGNvbnNvbGUubG9nKCdFdmVudDonLCBKU09OLnN0cmluZ2lmeShldmVudCwgbnVsbCwgMikpXG4gICAgXG4gICAgY29uc3QgYm9keSA9IEpTT04ucGFyc2UoZXZlbnQuYm9keSlcbiAgICBjb25zdCB7IGFuc3dlcnMsIHVzZXJJZCB9ID0gYm9keVxuICAgIFxuICAgIGlmICghYW5zd2Vycykge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgc3RhdHVzQ29kZTogNDAwLFxuICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgICAgICAnQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luJzogJyonLFxuICAgICAgICAgICdBY2Nlc3MtQ29udHJvbC1BbGxvdy1IZWFkZXJzJzogJ0NvbnRlbnQtVHlwZScsXG4gICAgICAgICAgJ0FjY2Vzcy1Db250cm9sLUFsbG93LU1ldGhvZHMnOiAnUE9TVCwgT1BUSU9OUydcbiAgICAgICAgfSxcbiAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxuICAgICAgICAgIGVycm9yOiAn55u46KuH5YaF5a6544GM5o+Q5L6b44GV44KM44Gm44GE44G+44Gb44KTJyxcbiAgICAgICAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgICAgfSlcbiAgICAgIH1cbiAgICB9XG4gICAgXG4gICAgLy8g44OH44O844K/44OZ44O844K544GL44KJ44Ku44OV44OI5Y+W5b6XXG4gICAgY29uc3QgZ2lmdHMgPSBhd2FpdCBnZXRHaWZ0c0Zyb21EYXRhYmFzZShhbnN3ZXJzKVxuICAgIFxuICAgIGlmIChnaWZ0cy5sZW5ndGggPT09IDApIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHN0YXR1c0NvZGU6IDQwNCxcbiAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICAgICAgJ0FjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpbic6ICcqJyxcbiAgICAgICAgICAnQWNjZXNzLUNvbnRyb2wtQWxsb3ctSGVhZGVycyc6ICdDb250ZW50LVR5cGUnLFxuICAgICAgICAgICdBY2Nlc3MtQ29udHJvbC1BbGxvdy1NZXRob2RzJzogJ1BPU1QsIE9QVElPTlMnXG4gICAgICAgIH0sXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICBzdWNjZXNzOiBmYWxzZSxcbiAgICAgICAgICBlcnJvcjogJ+adoeS7tuOBq+WQiOOBhuOCruODleODiOOBjOimi+OBpOOBi+OCiuOBvuOBm+OCk+OBp+OBl+OBnycsXG4gICAgICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICAgIH0pXG4gICAgICB9XG4gICAgfVxuICAgIFxuICAgIC8vIEFJ5o6o6Jam55Sf5oiQXG4gICAgY29uc3QgYWlFeHBsYW5hdGlvbiA9IGF3YWl0IGdlbmVyYXRlQUlSZWNvbW1lbmRhdGlvbnMoYW5zd2VycylcbiAgICBcbiAgICAvLyDkuIrkvY0z44Gk44Gu44Ku44OV44OI44KS6YG45oqeXG4gICAgY29uc3QgcmVjb21tZW5kYXRpb25zID0gZ2lmdHMuc2xpY2UoMCwgMylcbiAgICBcbiAgICAvLyDnm7joq4flsaXmrbTkv53lrZjvvIh1c2VySWTjgYzlrZjlnKjjgZfjgarjgYTloLTlkIjjga/jg4fjg5Xjgqnjg6vjg4jlgKTjgpLoqK3lrprvvIlcbiAgICBjb25zdCBkZWZhdWx0VXNlcklkID0gdXNlcklkIHx8ICdhbm9ueW1vdXMnXG4gICAgY29uc3QgY29uc3VsdGF0aW9uSWQgPSBhd2FpdCBzYXZlQ29uc3VsdGF0aW9uKGRlZmF1bHRVc2VySWQsIGFuc3dlcnMsIHJlY29tbWVuZGF0aW9ucylcbiAgICBcbiAgICByZXR1cm4ge1xuICAgICAgc3RhdHVzQ29kZTogMjAwLFxuICAgICAgaGVhZGVyczoge1xuICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICAnQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luJzogJyonLFxuICAgICAgICAnQWNjZXNzLUNvbnRyb2wtQWxsb3ctSGVhZGVycyc6ICdDb250ZW50LVR5cGUnLFxuICAgICAgICAnQWNjZXNzLUNvbnRyb2wtQWxsb3ctTWV0aG9kcyc6ICdQT1NULCBPUFRJT05TJ1xuICAgICAgfSxcbiAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgc3VjY2VzczogdHJ1ZSxcbiAgICAgICAgZGF0YToge1xuICAgICAgICAgIGNvbnN1bHRhdGlvbklkOiBjb25zdWx0YXRpb25JZC50b1N0cmluZygpLFxuICAgICAgICAgIHJlY29tbWVuZGF0aW9ucyxcbiAgICAgICAgICBhaUV4cGxhbmF0aW9uLFxuICAgICAgICB9LFxuICAgICAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgIH0pXG4gICAgfVxuICAgIFxuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yOicsIGVycm9yKVxuICAgIFxuICAgIHJldHVybiB7XG4gICAgICBzdGF0dXNDb2RlOiA1MDAsXG4gICAgICBoZWFkZXJzOiB7XG4gICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICAgICdBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW4nOiAnKicsXG4gICAgICAgICdBY2Nlc3MtQ29udHJvbC1BbGxvdy1IZWFkZXJzJzogJ0NvbnRlbnQtVHlwZScsXG4gICAgICAgICdBY2Nlc3MtQ29udHJvbC1BbGxvdy1NZXRob2RzJzogJ1BPU1QsIE9QVElPTlMnXG4gICAgICB9LFxuICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICBzdWNjZXNzOiBmYWxzZSxcbiAgICAgICAgZXJyb3I6ICfjgq7jg5Xjg4jmjqjolqbjga7nlJ/miJDjgavlpLHmlZfjgZfjgb7jgZfjgZ8nLFxuICAgICAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgIH0pXG4gICAgfVxuICB9XG59ICJdfQ==